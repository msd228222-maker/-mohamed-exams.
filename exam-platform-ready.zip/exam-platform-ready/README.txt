# منصة امتحانات الطالب - ملفات الربط

## الموجود
- `index.html`: واجهة تستدعي Edge Function بدل تخزين الإجابات الصحيحة داخل المتصفح.
- `supabase/functions/exam-api/index.ts`: كود Edge Function لجلب الأسئلة وتصحيحها على الخادم.

## مهم قبل النشر
1. في Supabase > Edge Functions أنشئ function باسم `exam-api` والصق محتوى `index.ts`.
2. أضف Secret باسم `SUPABASE_SERVICE_ROLE_KEY` بقيمة Service Role key من Project Settings > API. لا تضع هذا المفتاح في HTML ولا ترسله لأي شخص.
3. تأكد أن جدول `exam_questions` يحتوي أعمدة مناسبة: `exam_id`, `question_text`, `options` (JSON array), `correct_index`, `explanation`, `question_order`.
4. تأكد أن جدول `exams` يحتوي `id` و`title` أو `name`.
5. تأكد أن `exam_sessions` يقبل الأعمدة المستخدمة في insert: `exam_id`, `student_name`, `score`, `total_questions`, `percentage`, `answers`, `submitted_at`. إن كانت أسماء الأعمدة مختلفة، عدّل insert في الدالة حسب الجدول الفعلي.
6. انشر الدالة، ثم ارفع `index.html` إلى موقعك.

## ملاحظة أمان
لا تستخدم سياسة INSERT مفتوحة على جدول النتائج من المتصفح. هذا الكود يحسب الدرجة على الخادم. اجعل الجداول الحساسة غير متاحة مباشرة لـ anon/authenticated، ولا تعرض `correct_index` أو `explanation` في استجابة get_exam.
