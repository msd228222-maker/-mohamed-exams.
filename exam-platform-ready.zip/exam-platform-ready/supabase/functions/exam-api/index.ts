import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) return json({ error: "إعدادات الخادم ناقصة: SUPABASE_URL أو SUPABASE_SERVICE_ROLE_KEY" }, 500);

    const supabase = createClient(url, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const body = await req.json();
    const action = body.action;

    if (action === "get_exam") {
      // Returns only question text/options. Correct answers and explanations stay server-side.
      const { data: exams, error: examError } = await supabase
        .from("exams").select("*").limit(100);
      if (examError) throw examError;
      const exam = (exams || []).find((e: any) =>
        String(e.title || e.name || "").includes("المحاضرة الأولى")
      ) || (exams || [])[0];
      if (!exam) return json({ error: "لم يتم العثور على امتحان في جدول exams" }, 404);

      const { data: rows, error: qError } = await supabase
        .from("exam_questions").select("*")
        .eq("exam_id", exam.id)
        .order("question_order", { ascending: true });
      if (qError) throw qError;

      const questions = (rows || []).map((r: any) => ({
        id: r.id,
        question_text: r.question_text ?? r.question ?? r.q ?? "",
        options: normalizeOptions(r.options ?? r.choices ?? r.answers),
      }));
      if (!questions.length) return json({ error: "لم يتم العثور على أسئلة مرتبطة بالامتحان" }, 404);
      return json({ exam: { id: exam.id, title: exam.title || exam.name || "امتحان المحاضرة الأولى" }, questions });
    }

    if (action === "submit") {
      const examId = body.exam_id;
      const answers = body.answers;
      const studentName = String(body.student_name || "").trim().slice(0, 120);
      if (!examId || !Array.isArray(answers)) return json({ error: "بيانات التسليم ناقصة" }, 400);

      const { data: rows, error } = await supabase
        .from("exam_questions").select("*")
        .eq("exam_id", examId)
        .order("question_order", { ascending: true });
      if (error) throw error;
      if (!rows?.length) return json({ error: "الامتحان غير موجود أو لا يحتوي على أسئلة" }, 404);

      let score = 0;
      const review = rows.map((r: any, i: number) => {
        const options = normalizeOptions(r.options ?? r.choices ?? r.answers);
        const correct = Number(r.correct_index ?? r.correct_answer_index ?? r.correct);
        const selected = Number(answers[i]);
        const isAnswered = Number.isInteger(selected) && selected >= 0 && selected < options.length;
        const isCorrect = isAnswered && selected === correct;
        if (isCorrect) score++;
        return {
          question: r.question_text ?? r.question ?? r.q ?? "",
          user_answer: isAnswered ? options[selected] : "لم تختر إجابة",
          correct_answer: options[correct] ?? "",
          explanation: r.explanation ?? "",
          is_correct: isCorrect,
        };
      });

      const total = rows.length;
      const percentage = Math.round(score / total * 100);

      // Persist the server-calculated result. Adjust column names here only if your
      // existing exam_sessions table uses different names.
      const { error: saveError } = await supabase.from("exam_sessions").insert({
        exam_id: examId,
        student_name: studentName || "طالب",
        score,
        total_questions: total,
        percentage,
        answers: answers,
        submitted_at: new Date().toISOString(),
      });
      if (saveError) {
        // Do not discard the student's calculated result if optional logging schema differs.
        console.error("Could not save exam session:", saveError.message);
      }

      return json({ score, total, percentage, review, saved: !saveError });
    }

    return json({ error: "قيمة action غير صحيحة" }, 400);
  } catch (err) {
    console.error(err);
    return json({ error: err?.message || "حدث خطأ داخلي" }, 500);
  }
});

function normalizeOptions(value: any): string[] {
  if (Array.isArray(value)) return value.map((x) => String(x));
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map((x) => String(x));
    } catch { /* ignore */ }
    return value.split(/\r?\n/).filter(Boolean);
  }
  return [];
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}
